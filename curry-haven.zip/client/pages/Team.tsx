import Placeholder from "./Placeholder";

export default function Team() {
  return (
    <Placeholder
      title="Meet Our Doctors"
      description="Profiles, qualifications, and availability of our expert team will appear here."
    />
  );
}
