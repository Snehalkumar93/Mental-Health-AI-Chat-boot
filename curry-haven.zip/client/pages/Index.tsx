import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

export default function Index() {
  return (
    <main className="min-h-screen">
      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-br from-primary/10 via-sky-50 to-white">
        <div className="container grid gap-12 py-16 md:grid-cols-2 md:py-24">
          <div className="flex flex-col justify-center">
            <span className="mb-4 inline-flex items-center gap-2 rounded-full border border-primary/20 bg-white px-3 py-1 text-xs font-medium text-primary shadow-sm">
              <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 2v20M2 12h20"/></svg>
              Trusted Family Healthcare
            </span>
            <h1 className="text-4xl font-extrabold leading-tight tracking-tight md:text-5xl">
              Comprehensive healthcare for the whole family
            </h1>
            <p className="mt-4 max-w-xl text-muted-foreground">
              Expert doctors, modern facilities, and compassionate care—delivering the best outcomes with a personal touch.
            </p>
            <div className="mt-6 flex flex-wrap items-center gap-3">
              <Button asChild className="shadow-sm">
                <Link to="/contact">Make appointment</Link>
              </Button>
              <Button asChild variant="outline">
                <Link to="/services">Explore services</Link>
              </Button>
            </div>
            <div className="mt-10 grid max-w-lg grid-cols-3 gap-4 text-center md:text-left">
              <Stat value="98%" label="Patient satisfaction"/>
              <Stat value="50+" label="Expert doctors"/>
              <Stat value="24/7" label="Emergency support"/>
            </div>
          </div>

          <div className="relative">
            <div className="relative mx-auto aspect-[4/5] w-4/5 overflow-hidden rounded-3xl bg-white shadow-2xl ring-1 ring-black/5 md:w-full">
              <img
                src="https://images.unsplash.com/photo-1582750433449-648ed127bb54?q=80&w=1400&auto=format&fit=crop"
                alt="Doctor with patient"
                className="h-full w-full object-cover"
              />
            </div>
            <div className="absolute -left-6 -top-6 hidden rounded-2xl bg-white/80 p-4 shadow-lg ring-1 ring-black/5 backdrop-blur md:block">
              <div className="text-sm font-semibold">Same-day Visits</div>
              <div className="text-xs text-muted-foreground">Fast and convenient</div>
            </div>
            <div className="absolute -right-4 bottom-10 hidden rounded-2xl bg-white/80 p-4 shadow-lg ring-1 ring-black/5 backdrop-blur md:block">
              <div className="text-sm font-semibold">ISO Certified</div>
              <div className="text-xs text-muted-foreground">Quality you can trust</div>
            </div>
          </div>
        </div>
      </section>

      {/* Services */}
      <section className="container py-20">
        <div className="mx-auto mb-12 max-w-2xl text-center">
          <h2 className="text-3xl font-bold tracking-tight md:text-4xl">Comprehensive medical services</h2>
          <p className="mt-3 text-muted-foreground">From preventive care to advanced diagnostics and treatment.</p>
        </div>
        <div className="grid gap-6 md:grid-cols-3">
          <ServiceCard icon={<Stethoscope />} title="Primary Care" desc="Routine checkups, vaccinations, and chronic care management." />
          <ServiceCard icon={<Heart />} title="Cardiology" desc="Heart health assessments and personalized treatment plans." />
          <ServiceCard icon={<Tooth />} title="Dental Care" desc="Complete oral care for healthy smiles at every age." />
          <ServiceCard icon={<Activity />} title="Diagnostics" desc="On-site lab tests and imaging for faster results." />
          <ServiceCard icon={<Baby />} title="Pediatrics" desc="Compassionate care tailored for children and teens." />
          <ServiceCard icon={<UserCheck />} title="Telehealth" desc="Virtual consultations with our specialists." />
        </div>
      </section>

      {/* Feature / Why choose us */}
      <section className="bg-gradient-to-b from-white to-sky-50">
        <div className="container grid items-center gap-10 py-20 md:grid-cols-2">
          <div className="order-2 md:order-1">
            <ul className="space-y-4">
              {[
                "Board-certified doctors with years of experience",
                "Modern equipment and evidence-based protocols",
                "Personalized care plans for every patient",
                "Cashless insurance and easy payments",
                "Accessible location with ample parking",
              ].map((item) => (
                <li key={item} className="flex items-start gap-3 rounded-xl bg-white p-4 shadow-sm ring-1 ring-black/5">
                  <span className="mt-1 inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-emerald-100 text-emerald-700">
                    <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2"><path d="M20 6L9 17l-5-5"/></svg>
                  </span>
                  <span className="text-sm md:text-base">{item}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="order-1 md:order-2">
            <div className="mx-auto aspect-[4/3] w-full overflow-hidden rounded-3xl shadow-2xl ring-1 ring-black/5">
              <img
                src="https://images.unsplash.com/photo-1584467735871-2bb4df5fdfc9?q=80&w=1400&auto=format&fit=crop"
                alt="Medical team"
                className="h-full w-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Doctors */}
      <section className="container py-20">
        <div className="mb-10 flex items-end justify-between">
          <div>
            <h2 className="text-3xl font-bold tracking-tight md:text-4xl">Our expert team</h2>
            <p className="mt-2 text-muted-foreground">Skilled, caring, and dedicated to your wellbeing.</p>
          </div>
          <Button asChild variant="outline" className="hidden md:inline-flex">
            <Link to="/team">View all</Link>
          </Button>
        </div>
        <div className="grid gap-6 md:grid-cols-3">
          {[
            {
              name: "Dr. Amelia Carter",
              role: "Cardiologist",
              img: "https://images.unsplash.com/photo-1550831107-1553da8c8464?q=80&w=1200&auto=format&fit=crop",
            },
            {
              name: "Dr. Lucas Patel",
              role: "Pediatrician",
              img: "https://images.unsplash.com/photo-1537368910025-700350fe46c7?q=80&w=1200&auto=format&fit=crop",
            },
            {
              name: "Dr. Sofia Nguyen",
              role: "General Physician",
              img: "https://images.unsplash.com/photo-1551601651-2a8555f1a136?q=80&w=1200&auto=format&fit=crop",
            },
          ].map((d) => (
            <div key={d.name} className="group overflow-hidden rounded-2xl bg-white shadow-sm ring-1 ring-black/5">
              <div className="aspect-[4/3] w-full overflow-hidden">
                <img src={d.img} alt={d.name} className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-[1.03]" />
              </div>
              <div className="p-5">
                <div className="font-semibold">{d.name}</div>
                <div className="text-sm text-muted-foreground">{d.role}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Appointment CTA */}
      <section className="relative overflow-hidden py-20">
        <div className="container">
          <div className="relative grid items-center gap-8 overflow-hidden rounded-3xl bg-gradient-to-r from-primary to-sky-500 p-8 text-primary-foreground shadow-2xl md:grid-cols-[1.1fr_1fr] md:p-12">
            <div>
              <h3 className="text-2xl font-bold md:text-3xl">Book your appointment in minutes</h3>
              <p className="mt-2 max-w-md text-white/90">Choose your doctor, select a time, and get the care you need—on your terms.</p>
              <div className="mt-6 flex flex-wrap gap-3">
                <Button asChild variant="secondary" className="text-primary">
                  <Link to="/contact">Book now</Link>
                </Button>
                <Button asChild variant="outline" className="border-white/50 text-white hover:bg-white/10">
                  <Link to="/team">Meet our doctors</Link>
                </Button>
              </div>
            </div>
            <form className="rounded-2xl bg-white p-4 text-foreground shadow-xl">
              <div className="grid gap-3 md:grid-cols-2">
                <Input label="Full name" placeholder="Enter your name" />
                <Input label="Phone" placeholder="(555) 000-0000" />
                <Input label="Email" placeholder="you@example.com" />
                <Input label="Date" type="date" />
                <div className="md:col-span-2">
                  <Input label="Reason" placeholder="Checkup, consultation, etc." />
                </div>
              </div>
              <Button className="mt-4 w-full">Confirm appointment</Button>
            </form>
          </div>
        </div>
      </section>

      {/* Blog */}
      <section className="container py-20">
        <div className="mx-auto mb-12 max-w-2xl text-center">
          <h2 className="text-3xl font-bold tracking-tight md:text-4xl">News & articles</h2>
          <p className="mt-3 text-muted-foreground">Timely tips to help you live healthier.</p>
        </div>
        <div className="grid gap-6 md:grid-cols-3">
          {[
            {
              title: "5 ways to keep your heart healthy",
              img: "https://images.unsplash.com/photo-1516549655169-df83a0774514?q=80&w=1200&auto=format&fit=crop",
            },
            {
              title: "Understanding childhood vaccinations",
              img: "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?q=80&w=1200&auto=format&fit=crop",
            },
            {
              title: "How often should you get a checkup?",
              img: "https://images.unsplash.com/photo-1505751172876-fa1923c5c528?q=80&w=1200&auto=format&fit=crop",
            },
          ].map((a) => (
            <article key={a.title} className="group overflow-hidden rounded-2xl bg-white shadow-sm ring-1 ring-black/5">
              <div className="aspect-[4/3] w-full overflow-hidden">
                <img src={a.img} alt="Article" className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-[1.03]" />
              </div>
              <div className="p-5">
                <h3 className="line-clamp-2 font-semibold">{a.title}</h3>
                <div className="mt-3 text-sm text-muted-foreground">3 min read</div>
              </div>
            </article>
          ))}
        </div>
      </section>
    </main>
  );
}

function Stat({ value, label }: { value: string; label: string }) {
  return (
    <div className="rounded-xl bg-white p-4 shadow-sm ring-1 ring-black/5">
      <div className="text-2xl font-extrabold text-primary">{value}</div>
      <div className="text-xs text-muted-foreground">{label}</div>
    </div>
  );
}

function ServiceCard({ icon, title, desc }: { icon: React.ReactNode; title: string; desc: string }) {
  return (
    <div className="group rounded-2xl bg-white p-6 shadow-sm ring-1 ring-black/5 transition hover:shadow-md">
      <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary">
        {icon}
      </div>
      <div className="font-semibold">{title}</div>
      <p className="mt-1 text-sm text-muted-foreground">{desc}</p>
    </div>
  );
}

function Input({ label, ...props }: React.InputHTMLAttributes<HTMLInputElement> & { label: string }) {
  return (
    <label className="grid w-full gap-1 text-sm">
      <span className="font-medium text-foreground/80">{label}</span>
      <input
        {...props}
        className="h-10 rounded-md border border-input bg-background px-3 text-sm shadow-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
      />
    </label>
  );
}

// icons
function Stethoscope() {
  return (
    <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 3v6a6 6 0 0 0 6 6h0a6 6 0 0 0 6-6V3"></path>
      <path d="M9 9v3a3 3 0 0 1-3 3h0"></path>
      <path d="M15 9v3a3 3 0 0 0 3 3h0"></path>
      <path d="M21 16a3 3 0 1 1-3-3"></path>
    </svg>
  );
}
function Heart() {
  return (
    <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.6l-1-1a5.5 5.5 0 0 0-7.8 7.8l1 1L12 22l7.8-8.6 1-1a5.5 5.5 0 0 0 0-7.8Z"></path>
    </svg>
  );
}
function Tooth() {
  return (
    <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M6.5 20c.5-2 1.5-3 3-3s2 1 2.5 3 1 3 2.5 3 2-1 2.5-3c.5-2 1.5-3 3-3s2 1 2.5 3"></path>
      <path d="M4 9a8 8 0 0 1 16 0c0 5-2 7-4 7s-2-2-4-2-2 2-4 2-4-2-4-7Z"></path>
    </svg>
  );
}
function Activity() {
  return (
    <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M22 12H18l-2 7L8 5l-2 7H2"></path>
    </svg>
  );
}
function Baby() {
  return (
    <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M9 12a3 3 0 0 1 6 0"></path>
      <path d="M19 12a7 7 0 1 1-14 0 7 7 0 0 1 14 0Z"></path>
      <path d="M12 19v3"></path>
    </svg>
  );
}
function UserCheck() {
  return (
    <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path>
      <circle cx="9" cy="7" r="4"></circle>
      <path d="m16 11 2 2 4-4"></path>
    </svg>
  );
}
