import { Link } from "react-router-dom";

export default function Footer() {
  return (
    <footer className="mt-24 bg-[hsl(222_47%_11%)] text-[hsl(210_40%_98%)]">
      <div className="container grid gap-10 py-14 md:grid-cols-4">
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <span className="inline-flex h-9 w-9 items-center justify-center rounded-md bg-gradient-to-tr from-primary to-sky-400 text-white">
              <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M12 2v20M2 12h20" />
              </svg>
            </span>
            <span className="text-xl font-extrabold tracking-tight">AroHealth</span>
          </div>
          <p className="max-w-xs text-sm text-white/70">
            Comprehensive, compassionate healthcare for the whole family with modern facilities and expert doctors.
          </p>
        </div>
        <div>
          <h4 className="mb-3 font-semibold">Company</h4>
          <ul className="space-y-2 text-sm text-white/80">
            <li>
              <Link className="hover:text-white" to="/services">Services</Link>
            </li>
            <li>
              <Link className="hover:text-white" to="/team">Our Doctors</Link>
            </li>
            <li>
              <Link className="hover:text-white" to="/blog">Blog</Link>
            </li>
            <li>
              <Link className="hover:text-white" to="/contact">Contact</Link>
            </li>
          </ul>
        </div>
        <div>
          <h4 className="mb-3 font-semibold">Contact</h4>
          <ul className="space-y-2 text-sm text-white/80">
            <li>Mon - Sat: 8:00 AM - 8:00 PM</li>
            <li>+1 (555) 123-4567</li>
            <li>care@arohealth.com</li>
            <li>12 Wellness Ave, San Francisco, CA</li>
          </ul>
        </div>
        <div>
          <h4 className="mb-3 font-semibold">Newsletter</h4>
          <p className="mb-3 text-sm text-white/70">Get health tips and clinic updates.</p>
          <form className="flex gap-2">
            <input type="email" required placeholder="Your email" className="w-full rounded-md border border-white/20 bg-white/10 px-3 py-2 text-sm placeholder:text-white/60 focus:outline-none focus:ring-2 focus:ring-white/30" />
            <button className="inline-flex shrink-0 items-center rounded-md bg-white px-4 text-sm font-medium text-[hsl(222_47%_11%)] hover:bg-white/90">
              Subscribe
            </button>
          </form>
        </div>
      </div>
      <div className="border-t border-white/10 py-4 text-center text-sm text-white/70">
        © {new Date().getFullYear()} AroHealth. All rights reserved.
      </div>
    </footer>
  );
}
