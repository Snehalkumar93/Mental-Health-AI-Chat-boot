import Placeholder from "./Placeholder";

export default function Services() {
  return (
    <Placeholder
      title="Our Medical Services"
      description="This page will list all specialties, diagnostics, and treatments. Ask to fill it out when you're ready."
    />
  );
}
