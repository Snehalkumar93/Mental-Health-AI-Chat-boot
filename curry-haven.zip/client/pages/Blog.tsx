import Placeholder from "./Placeholder";

export default function Blog() {
  return (
    <Placeholder
      title="Health News & Articles"
      description="Educational content and clinic updates will be published here."
    />
  );
}
