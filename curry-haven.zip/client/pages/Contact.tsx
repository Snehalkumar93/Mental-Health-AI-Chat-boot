import Placeholder from "./Placeholder";

export default function Contact() {
  return (
    <Placeholder
      title="Book an Appointment"
      description="Online booking and contact details will be added to this page."
    />
  );
}
